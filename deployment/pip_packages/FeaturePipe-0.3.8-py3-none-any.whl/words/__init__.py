from words.preprocessing import Cleaner
from words.setup_logger import logger
__version__ = "0.0.02"