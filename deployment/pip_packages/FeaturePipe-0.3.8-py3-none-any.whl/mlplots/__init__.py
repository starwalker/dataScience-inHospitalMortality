from mlplots.plot_methods import ClassificationPlot, ShaplyPlot, PlotStickMan, Interaction, importance_plot
__version__ = "0.0.4"